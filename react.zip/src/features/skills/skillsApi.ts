// skillsAPI.ts
export const fetchSkillsFromApi = async () => {
  const response = await fetch('/api/skills');
  if (!response.ok) {
    throw new Error('Failed to fetch skills');
  }
  return response.json();
};

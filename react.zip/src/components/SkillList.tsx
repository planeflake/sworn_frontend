import React, { useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../app/hooks';
import { fetchSkills, selectSkills } from '../features/skills/skillsSlice';

const SkillList: React.FC = () => {
  const dispatch = useAppDispatch();
  const skills = useAppSelector(selectSkills);

  useEffect(() => {
    dispatch(fetchSkills());
  }, [dispatch]);

  return (
    <div>
      <h2>Skills List</h2>
      <ul>
        {skills.map((skill) => (
          <li key={skill.id}>
            <strong>{skill.name}</strong> ({skill.category})
            {skill.parent_skill_name && (
              <p>Parent Skill: {skill.parent_skill_name}</p>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SkillList;
